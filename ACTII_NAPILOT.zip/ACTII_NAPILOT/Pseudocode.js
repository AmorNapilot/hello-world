//Queue Array List
while Q is not Empty do{
	if (S is Empty or top(S) < head(Q))
{
	x=Dequeque(Q);
	Push(S,x);
}
else{
	x=Pop(S);
	Enqueueq(Q,x);
}
}
//Queue Linked List
int H(treeptr n){
if (n == NULL){
	return -1;
}
	if (nLeft == NULL ){
		if (nRight == NULL){
			return 0;
		}

else{
	return B1;
}
}
else{
	(h1 - height (nLeft));
}
if (mRight -- NULL) {
	return (1+h1);
}
else {
	h2 = height (nRight);
return B2;
}
}
}

//Stacks Array List
Algorithm push(o):
if (size()= N){
	throw a StackFUllException
	t=t+1;
	S[t]=o;
} 
Algorithm pop():
if(isEmpty()){
	throw SackEmptyExeption
	e=S[t]
	S[t]=null
	t=t-1
}return e;

//Stakcs Linked List
void Reverse(char *C, int n){
	stack<char> S;

	for(int 1=0; i<n; i++){
	S.push(C[i]);
	}

	for (int i=0; i<n; i++){
	C[i]=S.top();
	S.pop();
	}
}
